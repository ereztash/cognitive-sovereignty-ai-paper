from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
RESULTS.mkdir(exist_ok=True)
FIGURES.mkdir(exist_ok=True)
np.random.seed(42)
T, N = 40, 400
CONDITIONS = {
    "No AI": {"offload": 0.00, "calibration": 0.55, "foundational": 0.65, "reflection": 0.55},
    "Uncalibrated AI": {"offload": 0.85, "calibration": 0.25, "foundational": 0.45, "reflection": 0.20},
    "Calibrated AI": {"offload": 0.65, "calibration": 0.70, "foundational": 0.60, "reflection": 0.65},
    "Fortified AI": {"offload": 0.55, "calibration": 0.85, "foundational": 0.75, "reflection": 0.85},
}

def simulate(condition, n=N, sessions=T):
    p = CONDITIONS[condition]
    records = []
    for participant in range(n):
        knowledge = np.clip(np.random.normal(p["foundational"], 0.10), 0.05, 0.95)
        critical = np.clip(np.random.normal(0.55, 0.08), 0.05, 0.95)
        sovereignty = np.clip(np.random.normal(0.60, 0.08), 0.05, 0.95)
        for session in range(1, sessions + 1):
            productive_effort = np.clip((1 - p["offload"]) + 0.55 * p["reflection"] * p["calibration"], 0, 1)
            performance = 0.35 * knowledge + 0.35 * p["offload"] + 0.20 * critical + 0.10 * p["calibration"] + np.random.normal(0, 0.04)
            learning_gain = 0.018 * productive_effort * (0.5 + p["calibration"]) * (0.6 + p["reflection"])
            hollowing_penalty = 0.014 * p["offload"] * (1 - p["calibration"]) * (1 - knowledge)
            critical = np.clip(critical + learning_gain - hollowing_penalty + np.random.normal(0, 0.006), 0, 1)
            sovereignty_gain = 0.015 * p["calibration"] * p["reflection"] * knowledge
            dependency_penalty = 0.018 * p["offload"] * (1 - p["calibration"]) * (1 - p["reflection"])
            sovereignty = np.clip(sovereignty + sovereignty_gain - dependency_penalty + np.random.normal(0, 0.006), 0, 1)
            records.append({"condition": condition, "participant": participant, "session": session, "performance": np.clip(performance, 0, 1), "critical_thinking": critical, "cognitive_sovereignty": sovereignty, "productive_effort": productive_effort})
    return pd.DataFrame(records)

def plot_trajectory(data, y, ylabel, title, filename):
    means = data.groupby(["condition", "session"])[y].mean().reset_index()
    plt.figure(figsize=(9, 5))
    for condition in CONDITIONS:
        subset = means[means["condition"] == condition]
        plt.plot(subset["session"], subset[y], label=condition)
    plt.xlabel("Session")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(FIGURES / filename, format="svg")
    plt.close()

def main():
    sim = pd.concat([simulate(c) for c in CONDITIONS], ignore_index=True)
    final = sim[sim["session"] == T].groupby("condition").agg(performance_mean=("performance", "mean"), critical_thinking_mean=("critical_thinking", "mean"), sovereignty_mean=("cognitive_sovereignty", "mean"), productive_effort_mean=("productive_effort", "mean")).reset_index()
    final["performance_sovereignty_gap"] = final["performance_mean"] - final["sovereignty_mean"]
    sim.to_csv(RESULTS / "simulation_session_level.csv", index=False, encoding="utf-8-sig")
    final.round(3).to_csv(RESULTS / "simulation_final_outcomes.csv", index=False, encoding="utf-8-sig")
    plot_trajectory(sim, "critical_thinking", "Mean critical thinking score", "Model prediction: critical thinking trajectory", "critical_thinking_trajectory.svg")
    plot_trajectory(sim, "cognitive_sovereignty", "Mean cognitive sovereignty score", "Model prediction: cognitive sovereignty trajectory", "sovereignty_trajectory.svg")
    print(final.round(3).to_string(index=False))

if __name__ == "__main__":
    main()
